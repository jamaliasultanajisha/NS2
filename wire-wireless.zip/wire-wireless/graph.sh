#!/bin/bash
dir="../../out/"
output_file_format="tcp";
under="_"
graph="GRAPH"
all="all"
nodeThr="nodeThr"
temp="temp"


cd out/
rm -rf graphs

mkdir graphs
cd graphs/


variation=1

while [ $variation -le 5 ] 
do
	if [ $variation -eq 1 ]; then 
		echo 
		echo 
		echo "*********GENERATING GRAPHS VARYING NUMBER OF NODES*********"
		vary="NodeNum"

	elif [ $variation -eq 2 ]; then 
		echo 
		echo 
		echo "*********GENERATING GRAPHS VARYING NUMBER OF FLOWS*********"
		vary="FlowNum"

	elif [ $variation -eq 3 ]; then 
		echo 
		echo 
		echo "*********GENERATING GRAPHS VARYING PACKETS PER SECOND*********"
		vary="PacketsPerSec"

	elif [ $variation -eq 4 ]; then 
		echo 
		echo 
		echo "*********GENERATING GRAPHS VARYING SPEED OF NODES*********"
		vary="NodeSpeed"
	elif [ $variation -eq 5 ]; then 
		echo 
		echo 
		echo "*********GENERATING GRAPHS VARYING QUEUE OF NODES*********"
		vary="NodeQueue"
			
	else 
		echo 
		echo 
		echo "*********WRONG*********"
	fi

	output_file2="$dir$output_file_format$under$vary$under$graph.out"

	node_thr_file="$dir$output_file_format$under$vary$under$nodeThr.out"


	gnuplot -persist <<-EOFMarker
		set style line 1 \
		    linecolor rgb '#0060ad' \
		    linetype 1 linewidth 2 \
		    pointtype 7 pointsize 1.5

		set xlabel '$vary'    

		set ylabel 'THR'
		set term png
		set output "THR VS $vary.png"    
		plot '$output_file2' using 1:2 with linespoints linestyle 1 title "Thr VS $vary"

		set ylabel 'Delay'
		set term png
		set output "Delay VS $vary.png"    
		plot '$output_file2' using 1:3 with linespoints linestyle 1 title "Delay VS $vary"

		set ylabel 'DelRatio'
		set term png
		set output "DelRatio VS $vary.png"    
		plot '$output_file2' using 1:4 with linespoints linestyle 1 title "DelRatio VS $vary"

		set ylabel 'DropRatio'
		set term png
		set output "DropRatio VS $vary.png"    
		plot '$output_file2' using 1:5 with linespoints linestyle 1 title "DropRatio VS $vary"


	EOFMarker


	#NODE THR FILE
	cat $node_thr_file | while read line 
	do

		first_val=$(echo $line | cut -d' ' -f 1)

		if [ $first_val -eq -1 ]; then
			curr_num_point=$(echo $line | cut -d' ' -f $(($variation+2)))
			#echo $curr_num_point
			temp_file="$dir$output_file_format$under$vary$under$temp$curr_num_point.out"
			rm -f $temp_file
			touch $temp_file

			#echo $temp_file

		else
			echo $line >> $temp_file

		fi
	
	done


	#======================================
	#PER_NODE THROUGHPUT GRAPHS WILL BE GENERATED IN BANGLA METHOD
	#======================================

	temp_file="$dir$output_file_format$under$vary$under$temp"

	if [ $variation -eq 1 ]; then 
		gnuplot -persist <<-EOFMarker
			set xlabel 'Node Number'    

			set ylabel 'PER-NODE THR'
			set term png
			set output "PER-NODE THR VS $vary.png"    
			plot '$temp_file$((100)).out' using 1:2 with line title "$vary = 100"

		EOFMarker

	elif [ $variation -eq 2 ]; then 
		gnuplot -persist <<-EOFMarker
			set xlabel 'Node Number'    

			set ylabel 'PER-NODE THR'
			set term png
			set output "PER-NODE THR VS $vary.png"    
			plot '$temp_file$((50)).out' using 1:2 with line title "$vary = 50"

		EOFMarker

	elif [ $variation -eq 3 ]; then 
		gnuplot -persist <<-EOFMarker
			set xlabel 'Node Number'    

			set ylabel 'PER-NODE THR'
			set term png
			set output "PER-NODE THR VS $vary.png"    
			plot '$temp_file$((500)).out' using 1:2 with line title "$vary = 500"

		EOFMarker

	elif [ $variation -eq 4 ]; then 
		gnuplot -persist <<-EOFMarker

			set xlabel 'Node Number'    

			set ylabel 'PER-NODE THR'
			set term png
			set output "PER-NODE THR VS $vary.png"    
			plot '$temp_file$((25)).out' using 1:2 with line title "$vary = 25"

		EOFMarker

	elif [ $variation -eq 5 ]; then 
		gnuplot -persist <<-EOFMarker

			set xlabel 'Node Number'    

			set ylabel 'PER-NODE THR'
			set term png
			set output "PER-NODE THR VS $vary.png"    
			plot '$temp_file$((125)).out' using 1:2 with line title "$vary = 125"

		EOFMarker
			
	else 
		echo 
		echo 
		echo "*********WRONG*********"
	fi


	echo Done generating $vary variation graphs
	variation=$(($variation+1))


done

cd ../..
